<?php

	// LISTS
	function funky_list( $atts, $content ) {
	
		extract( shortcode_atts( array(
			'style' => 'check'			// check | cross | circle | square
		), $atts ) );
		
		switch ( $style ) {
			case 'circle':
				$style = 'funky_circle';
				break;
			case 'square':
				$style = 'funky_square';
				break;
			case 'cross':
				$style = 'funky_cross';
				break;
			default:
				$style = 'funky_check';
		}
		
		
		return '<ul class="'. $style .'">'. do_shortcode( $content ) .'</ul>';
	
	}
	add_shortcode( 'funky_list', 'funky_list' );

?>