(function() {
	
	tinymce.create('tinymce.plugins.funky_shortcode_list', {		 
		init : function(ed, url) {
			
			ed.addCommand('mce_funky_shortcode_list', function () {
				
				ed.windowManager.open({
					
					file : url + '/window.php',
					width : 360 + ed.getLang('funky_shortcode_list.delta_width', 0),
					height : 140 + ed.getLang('funky_shortcode_list.delta_height', 0),
					inline : 1
					
				}, {
					
					plugin_url : url
					
				});
			});
			
			// lists
            ed.addButton( 'funky_list', {
                title : 'Insert styled list',
                image : url+'/icon.png',
				cmd : 'mce_funky_shortcode_list'
            });
			
		}		
	});

	tinymce.PluginManager.add('funky_list', tinymce.plugins.funky_shortcode_list);
	
})();