(function() {
	
	tinymce.create('tinymce.plugins.funky_shortcode_emphasis', {
		init : function(ed, url) {
			
			ed.addCommand('mce_funky_shortcode_emphasis', function() {
				
				ed.windowManager.open({
					
					file : url + '/window.php',
					width : 526 + ed.getLang('funky_shortcode_emphasis.delta_width', 0),
					height : 262 + ed.getLang('funky_shortcode_emphasis.delta_height', 0),
					inline : 1
					
				}, {
					
					plugin_url : url // Plugin absolute URL
					
				});
			});
			
			// emphasis
            ed.addButton('funky_emphasis', {
                title : 'Insert an emphasis styled text',
                image : url+'/icon.png',
                cmd : 'mce_funky_shortcode_emphasis'
            });
			
		}
		
	});

	tinymce.PluginManager.add('funky_emphasis', tinymce.plugins.funky_shortcode_emphasis);
	
})();