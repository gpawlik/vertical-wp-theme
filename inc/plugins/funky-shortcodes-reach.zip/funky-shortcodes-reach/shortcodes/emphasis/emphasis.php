<?php

	// EMPHASIS
	function funky_emphasis($atts, $content){
	
		extract( shortcode_atts(array(
			'align' => 'center' // Left | Right | Center
		), $atts));		
		
		return '<span class="emphasis '. $align .'">'. $content .'</span>';
		
	}
	add_shortcode('funky_emphasis', 'funky_emphasis');

?>