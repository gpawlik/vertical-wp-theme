(function() {
	
	tinymce.create('tinymce.plugins.funky_shortcode_pricing_table', {		 
		init : function(ed, url) {
			
			ed.addCommand('mce_funky_shortcode_pricing_table', function() {
				
				ed.windowManager.open({
					
					file : url + '/window.php',
					width : 403 + ed.getLang('funky_shortcode_pricing_table.delta_width', 0),
					height : 187 + ed.getLang('funky_shortcode_pricing_table.delta_height', 0),
					inline : 1
					
				}, {
					
					plugin_url : url
					
				});
			});
			
            ed.addButton( 'funky_pricing_table', {
                title:	'Insert page list',
                image:	url + '/icon.png',
				cmd:	'mce_funky_shortcode_pagelist'
            });
			
		}
		
	});

	tinymce.PluginManager.add('funky_pricing_table', tinymce.plugins.funky_shortcode_pricing_table);
	
})();