<?php
	
	// PRICING TABLE
	function funky_pricing_table( $atts, $content ) {	
		
		$columns = substr_count( $content, '[funky_pricing_table_column' );
		$highlight = substr_count( $content, 'highlight="true"' );
		
		$width = ( 177 * $columns ) + ( 48 * $highlight );

		return '<div class="funky-pricing-table clearfix" style="width: '. $width .'px;">'. do_shortcode( $content ) .'</div>';
	
	}
	add_shortcode( 'funky_pricing_table', 'funky_pricing_table' );
	
	// COLUMNS
	function funky_pricing_table_column( $atts,  $content ) {
		
		extract( shortcode_atts( array(
			'highlight' => 'false',				// ID of parent page.
		), $atts ) );
		
		if ( $highlight == "true" ) {
			return '<div class="funky-pricing-table-column pricing-table-column-highlight">'. do_shortcode( $content ) .'</div>';
		} else {
			return '<div class="funky-pricing-table-column">'. do_shortcode( $content ) .'</div>';			
		}
	
	}
	add_shortcode( 'funky_pricing_table_column', 'funky_pricing_table_column' );
	
	
	// ROWS
	function funky_pricing_table_row( $atts, $content ){
		
		return '<div class="funky-pricing-table-row">'. do_shortcode( $content ) .'</div>';
		
	}
	add_shortcode( 'funky_pricing_table_row', 'funky_pricing_table_row' );

?>