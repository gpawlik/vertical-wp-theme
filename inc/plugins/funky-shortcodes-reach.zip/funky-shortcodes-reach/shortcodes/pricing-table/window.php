<?php
	
	// Setup location of WordPress
	$absolute_path = __FILE__;
	$path_to_file = explode( 'wp-content', $absolute_path );
	$path_to_wp = $path_to_file[0];

	// Access WordPress
	require_once( $path_to_wp.'/wp-load.php' );

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<title><?php _e("Pricing Table Shortcode","raw_theme"); ?></title>
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<script language="javascript" type="text/javascript" src="<?php echo includes_url() ?>js/tinymce/utils/form_utils.js"></script>
	<script language="javascript" type="text/javascript" src="<?php echo includes_url(); ?>js/tinymce/tiny_mce_popup.js"></script>	
	<script language="javascript" type="text/javascript">
	function init() {
		
		tinyMCEPopup.resizeToInnerSize();
		
	}
	
	function insertShortcode() {
		
		var output;
		
		var pricing_columns = document.getElementById('pricing_columns').value;
		var pricing_rows = document.getElementById('pricing_rows').value;
		
		output = '[pricing_table] '; 
		
		var count = 1;
	
		while ( count <= pricing_columns ) {
			
			var row_count = 1;
			
			output = output+'[pricing_table_column highlight="false"] ';
			
			while ( row_count <= pricing_rows ) {
				
				output = output+'[pricing_table_row] [/pricing_table_row] ';
				
				row_count++;
			
			}
			
			output = output+'[/pricing_table_column] ';
			
			count++;
		}
		
		
		output = output+'[/pricing_table] '; 
		
		if(window.tinyMCE) {
			window.tinyMCE.execInstanceCommand('content', 'mceInsertContent', false, output);
			tinyMCEPopup.editor.execCommand('mceRepaint');
			tinyMCEPopup.close();
		}
		
		return;
	}
	</script>
	<base target="_self" />
    
	<style type="text/css">	
		label span { color: #F00; }	
    </style>
    
</head>
<body onload="init();">

	<form name="raw_pagelist_shortcodes" action="#">
		
		<div class="panel_wrapper">
			
			<fieldset style="padding-left: 15px;">
			
				<legend><?php _e("Options","raw_theme"); ?></legend>
				
				<br />
				
				<!-- COLUMNS -->
				<table border="0" cellpadding="4" cellspacing="0">				
					<tr>					 
						<td nowrap="nowrap"><label for="pricing_columns"><?php _e("Columns","raw_theme"); ?>:</label></td>						
						<td>						
							<select name="pricing_columns" id="pricing_columns" style="width: 210px"> 							
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3</option>
								<option value="4">4</option>							
							</select>						
						</td>						
					</tr>					  
				  </table>
				  
				<em style="font-size: 10px; padding: 5px 0 0 45px;"><?php _e("Select the number of columns in this pricing table","raw_theme"); ?></em><br />
				<br />
				
				<!-- COLUMNS -->
				<table border="0" cellpadding="4" cellspacing="0">				
					<tr>					 
						<td nowrap="nowrap"><label for="pricing_rows"><?php _e("Rows","raw_theme"); ?>:</label></td>						
						<td>						
							<select name="pricing_rows" id="pricing_rows" style="width: 210px"> 							
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3</option>
								<option value="4">4</option>
								<option value="5">5</option>
								<option value="6">6</option>
								<option value="7">7</option>
								<option value="8">8</option>
								<option value="9">9</option>
								<option value="10">10</option>
							</select>						
						</td>						
					</tr>					  
				  </table>
				  
				<em style="font-size: 10px; padding: 5px 0 0 45px;"><?php _e("Select the number rows in this pricing table","raw_theme"); ?></em><br />
				<br />
				
			</fieldset>
			
		</div>

		<div class="mceActionPanel">
			<input type="button" id="cancel" name="cancel" value="Close" style="float: left;" onclick="tinyMCEPopup.close();" />
			<input type="submit" id="insert" name="insert" value="Insert" style="float: right;" onclick="insertShortcode();" />
		</div>
		
	</form>
</body>
</html>
<?php

?>
