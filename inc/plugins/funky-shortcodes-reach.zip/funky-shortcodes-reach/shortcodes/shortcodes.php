<?php
	
/**
 *	Shortcode Array
 **/
$funky_shortcodes = array (
	'emphasis',
	'list',
	'portfolio',
	'pricing-table'
);

foreach ( $funky_shortcodes as $shortcode ) {
	require_once( dirname(__FILE__) .'/'. $shortcode .'/'. $shortcode .'.php' );
}


/**
 *	TinyMCE Buttons
 **/
function add_funky_shortcode_reach_buttons() {

	if ( current_user_can( 'edit_posts' ) || current_user_can( 'edit_pages' ) ) {
		add_filter( 'mce_buttons_3', 'register_funky_shortcode_raw_buttons' );
		add_filter( 'mce_external_plugins', 'add_funky_shortcode_reach_tinymce_plugin' );
	}

}
add_action( 'admin_init', 'add_funky_shortcode_reach_buttons' );


function register_funky_shortcode_raw_buttons( $buttons ) {
	
	array_push( $buttons,
		'funky_emphasis',
		'funky_list',
		'funky_portfolio',
		'funky_pricing_table'
	);
	
	return $buttons;
	
}


function add_funky_shortcode_reach_tinymce_plugin( $plugin_array ) {

	$plugin_array['funky_empahsis'] 		= plugins_url( '/shortcodes/emphasis/emphasis.js', dirname( __FILE__ ) );   
	$plugin_array['funky_list'] 			= plugins_url( '/shortcodes/list/list.js', dirname( __FILE__ ) );   
	$plugin_array['funky_portfolio'] 		= plugins_url( '/shortcodes/portfolio/portfolio.js', dirname( __FILE__ ) );   
	$plugin_array['funky_pricing_table'] 	= plugins_url( '/shortcodes/pricing-table/pricing-table.js', dirname( __FILE__ ) );
	
	return $plugin_array;

}