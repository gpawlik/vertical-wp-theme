// emphasis
edButtons[edButtons.length] =
new edButton('funky_emphasis'
,'emphasis'
,'[funky_emphasis align="left | center | right" ]'
,'[/funky_emphasis]'
,''
);

// list
edButtons[edButtons.length] =
new edButton('funky_list'
,'styled list'
,'[funky_list style="check | cross | circle | square" ]'
,'[/funky_list]'
,''
);

// pricing table
edButtons[edButtons.length] =
new edButton('funky_pricing_table'
,'pricing table'
,'[funky_pricing_table]\n\
[funky_pricing_table_column]\n\
[funky_pricing_table_row]Row content.[/funky_pricing_table_row]\n\
[/funky_pricing_table_column]\n\
[funky_pricing_table_column highlight="true"]\n\
[funky_pricing_table_row]Row content.[/funky_pricing_table_row]\n\
[/funky_pricing_table_column]\n\
[funky_pricing_table_column]\n\
[funky_pricing_table_row]Row content.[/funky_pricing_table_row]\n\
[/funky_pricing_table_column]\n[/funky_pricing_table]'
,''
,''
);


// Portfolio
edButtons[edButtons.length] =
new edButton('funky_portfolio'
,'portfolio'
,'[funky_portfolio category="Category slug" number="3" columns="1 | 2 | 3 | 4" orderby="date | menu_order | id | title | rand | parent | author" order="ASC | DESC" id="ID of specific pages (separated by a comma)" title="true | false" image="true | false" ]'
,''
,''
);
