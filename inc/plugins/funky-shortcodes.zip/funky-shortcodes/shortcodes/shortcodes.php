<?php

/**
 *	Shortcode Array
 **/
$funky_shortcodes = array	(
	"accordion",
	"accordion_item", 
	"box",
	"button",
	"clearboth",
	"columns",
	"divider",
	"dropcap",
	"highlight",
	"pages",
	"posts",
	"quote",
	"toggle"
);

foreach ( $funky_shortcodes as $shortcode ) {
	require_once( dirname(__FILE__) .'/'. $shortcode .'/'. $shortcode .'.php' );
}


function add_funky_shortcode_buttons() {

	if ( current_user_can( 'edit_posts' ) || current_user_can( 'edit_pages' ) ) {		
		add_filter( 'mce_external_plugins', 'add_funky_shortcode_tinymce_plugin' );
		add_filter( 'mce_buttons_2', 'register_funky_shortcode_button' );	
	}

}
add_action( 'admin_head', 'add_funky_shortcode_buttons' );

function add_funky_shortcode_tinymce_plugin( $plugin_array ) {
	
	$plugin_array['funky_shortcodes'] = plugins_url( '/shortcodes/shortcodes.js', dirname( __FILE__ ) ); 	
	return $plugin_array;

}


function register_funky_shortcode_button( $buttons ) {
 
    array_push( $buttons, 'funky_shortcodes' );
	return $buttons;
	
}