( function() {

	"use strict";    

	tinymce.PluginManager.add( 'funky_shortcodes', function( editor, url ) {
		
		editor.addButton( 'funky_shortcodes', {
			type: 'menubutton',
			text: 'Funky Shortcodes',
			classes: 'widget btn',
			icon: false,
			onselect: function(e) {}, 
			menu: [
			
				// ---------- Accordion ---------- //
				{
					text:		"Accordion",
					onclick:	function() {
						
						editor.focus();					
						editor.selection.setContent( '[funky_accordion]<br />\
							[funky_accordion_item open="true" title="*Accordion Title*"] *Accordion content goes here* [/funky_accordion_item]<br />\
							[funky_accordion_item title="*Accordion Title*"] *Accordion content goes here* [/funky_accordion_item]<br />\
							[funky_accordion_item title="*Accordion Title*"] *Accordion content goes here* [/funky_accordion_item]<br />\
							[/funky_accordion]' );
						
					}
				},
				
				// ---------- Accordion Item ---------- //
				{
					text:		"Accordion Item",
					onclick:	function() {
						
						editor.windowManager.open({
		
							file: url + '/accordion_item/window.php',
							width:	400 + editor.getLang( 'funky_shortcode_accordion_item.delta_width', 0 ),
							height: 416 + editor.getLang( 'funky_shortcode_accordion_item.delta_height', 0 ),
							inline: 1
							
						}, {
							
							plugin_url: url +'/accordion_item/'
							
						});
					
					}
				},
				
				// ---------- Box ---------- //
				{
					text:		"Box",
					onclick:	function() {
						
						editor.windowManager.open({
		
							file: url + '/box/window.php',
							width: 400 + editor.getLang( 'funky_shortcode_boxes.delta_width', 0 ),
							height: 315 + editor.getLang( 'funky_shortcode_boxes.delta_height', 0 ),
							inline: 1
							
						}, {
							
							plugin_url: url +'/box/'
							
						});
						
					}
				},
				
				// ---------- Button ---------- //
				{
					text:		"Button",
					onclick:	function() {
						
						editor.windowManager.open({
		
							file: url + '/button/window.php',
							width: 400 + editor.getLang( 'funky_shortcode_button.delta_width', 0 ),
							height: 535 + editor.getLang( 'funky_shortcode_button.delta_height', 0 ),
							inline: 1
							
						}, {
							
							plugin_url: url +'/button/'
							
						});
					
					}
				},
				
				// ---------- Clearboth ---------- //
				{
					text:		"Clearboth",
					onclick:	function() {
						
						editor.execCommand( 'mceInsertContent', false, '[funky_clearboth]' );
					
					}
				},
				
				// ---------- Columns ---------- //
				{
					text:		"Columns",
					onclick:	function() {
						
						editor.windowManager.open({
		
							file: url + '/columns/window.php',
							width: 400 + editor.getLang( 'funky_shortcode_columns.delta_width', 0 ),
							height: 140 + editor.getLang( 'funky_shortcode_columns.delta_height', 0 ),
							inline: 1
							
						}, {
							
							plugin_url: url +'/columns/'
							
						});
					
					}
				},
				
				// ---------- Divider ---------- //
				{
					text:		"Divider",
					onclick:	function() {
					
						editor.windowManager.open({
		
							file: url + '/divider/window.php',
							width: 400 + editor.getLang( 'funky_shortcode_divider.delta_width', 0 ),
							height: 142 + editor.getLang( 'funky_shortcode_divider.delta_height', 0 ),
							inline: 1
							
						}, {
							
							plugin_url: url +'/divider/'
							
						});
					
					}
				},
				
				// ---------- Dropcap ---------- //
				{
					text:		"Dropcap",
					onclick:	function() {
					
						editor.execCommand( 'mceInsertContent', false, '[funky_dropcap] *This should be an entire header or paragraph of text. Not just a single character* [/funky_dropcap]' );
					
					}
				},
				
				// ---------- Highlight ---------- //
				{
					text:		"Highlight",
					onclick:	function() {
					
						editor.windowManager.open({
		
							file: url + '/highlight/window.php',
							width: 400 + editor.getLang( 'funky_shortcode_highlight.delta_width', 0 ),
							height: 220 + editor.getLang( 'funky_shortcode_highlight.delta_height', 0 ),
							inline: 1
							
						}, {
							
							plugin_url: url +'/highlight/'
							
						});
					
					}
				},
				
				// ---------- Pages ---------- //
				{
					text:		"Pages",
					onclick:	function() {
					
						editor.windowManager.open({
		
							file: url + '/pages/window.php',
							width: 400 + editor.getLang( 'funky_shortcode_pagelist.delta_width', 0 ),
							height: 525 + editor.getLang( 'funky_shortcode_pagelist.delta_height', 0 ),
							inline: 1
							
						}, {
							
							plugin_url: url +'/pages/'
							
						});
					
					}
				},
				
				// ---------- Posts ---------- //
				{
					text:		"Posts",
					onclick:	function() {
					
						editor.windowManager.open({
		
							file: url + '/posts/window.php',
							width: 400 + editor.getLang( 'funky_shortcode_postlist.delta_width', 0 ),
							height: 315 + editor.getLang( 'funky_shortcode_postlist.delta_height', 0 ),
							inline: 1
							
						}, {
							
							plugin_url: url +'/posts/'
							
						});
					
					}
				},
				
				// ---------- Quote ---------- //
				{
					text:		"Quote",
					onclick:	function() {
					
						editor.windowManager.open({
		
							file: url + '/quote/window.php',
							width:	400 + editor.getLang( 'funky_shortcode_quotes.delta_width', 0 ),
							height: 315 + editor.getLang( 'funky_shortcode_quotes.delta_height', 0 ),
							inline: 1
							
						}, {
							
							plugin_url: url +'/quote/'
							
						});
					
					}
				},
				
				// ---------- Toggle ---------- //
				{
					text:		"Toggle",
					onclick:	function() {
					
						editor.windowManager.open({
		
							file: url + '/toggle/window.php',
							width:	400 + editor.getLang( 'funky_shortcode_toggle.delta_width', 0 ),
							height: 410 + editor.getLang( 'funky_shortcode_toggle.delta_height', 0 ),
							inline: 1
							
						}, {
							
							plugin_url: url +'/toggle/'
							
						});
					
					}
				}
				
			]
		});
		
	});
 
})();